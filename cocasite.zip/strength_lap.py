import flet as ft 


class StrengthLaptop(ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=700
        self.padding=ft.padding.only(0,25)
        self.content=ft.Column([
        ft.Container(
            expand=True,
            height=250,
            content=ft.Column([
                ft.Row([
                    
                    ft.Row([
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '17k',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'happy customers on worldwide',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=200,
    selectable=True,
                            )
                        ]),
                
                    ]),
                    ft.Column([
                        ft.Container(
                            width=1,
                            height=79,
                            bgcolor='grey',
                            offset=ft.transform.Offset(-12.5,0.4)
                        )
                    ]),
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '15+',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'Hours of work experience',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=150,
    selectable=True,
                            )
                        ]),
                    ]),
                ]),
                ft.Column([
                        ft.Container(
                            width=1,
                            height=79,
                            bgcolor='grey',
                            offset=ft.transform.Offset(-12.5,0.4)
                        )
                    ]),
                ft.Row([
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '50+',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'Creativity & passionate members',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=200,
    selectable=True,
                            )
                        ]),
                    ]),
                    ft.Column([
                        ft.Container(
                            width=1,
                            height=79,
                            bgcolor='grey',
                            offset=ft.transform.Offset(-12.5,0.4)
                        )
                    ]),
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '100+',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'Integrations lorem ipsum integrations',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=150,
    selectable=True,
                            )
                        ]),
                    ]),
                ]),
                ],alignment=ft.MainAxisAlignment.CENTER,expand=True)
            
            
        ],alignment=ft.MainAxisAlignment.CENTER,expand=True,spacing=75,height=250),
        ),
        
        ft.Row([
            ft.Image(
                src='images/image2.png',
                height=536,
            )
        ],alignment=ft.MainAxisAlignment.CENTER,expand=True,offset=ft.transform.Offset(0,-0.1),scale=ft.transform.Scale(1.6)),
        ft.Row([
            ft.Container(
                width=772,
                height=201,
                padding=ft.padding.only(35,0),
                content=ft.Row([
                    ft.Text(
                        'Lift your business to new heights with our digital marketing services',
                        size=35,
                        weight=ft.FontWeight.W_600,
                        color='black',
                        width=525,
                        expand_loose=True,
    selectable=True,
                    )
                ])
            ),
            ft.Container(
                width=428,
                height=128,
                content=ft.Row([
                    ft.Text(
                        'To build software that gives customer facing teams in small and medium-sized businesses the ability to create rewarding and long-lasting relationships with customers',
                        size=15.5,
                        color='grey',
                        width=350,
                        expand_loose=True,
    selectable=True,
                    )
                ]),
                offset=ft.transform.Offset(-0.65,0)
            )
        ],alignment=ft.MainAxisAlignment.CENTER,expand=True)
        
        
    ])