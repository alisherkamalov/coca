import flet as ft 
import time


home_click = ft.Container(
    content=ft.Text(
                'Home',
                color='black',
                size=15,
                weight=ft.FontWeight.W_400,
    selectable=True,
            ),
    on_click=True
)

about_click = ft.Container(
    content=ft.Text(
                'About',
                color='black',
                size=15,
                weight=ft.FontWeight.W_400,
    selectable=True,
            ),
    on_click=True
)

blog_click = ft.Container(
    content=ft.Text(
                'Blog',
                color='black',
                size=15,
                weight=ft.FontWeight.W_400,
    selectable=True,
            ),
    on_click=True
)

pricing_click = ft.Container(
    content=ft.Text(
                'Pricing',
                color='black',
                size=15,
                weight=ft.FontWeight.W_400,
    selectable=True,
            ),
    on_click=True
)

c_btn_text_mob = ft.Text(
        'Contact Us ->',
        color='black',
        size=15,
        weight=ft.FontWeight.W_500,
    selectable=True,
        )
contact_btn_mob = ft.Container(
    content=ft.Column([
        ft.Row([
        c_btn_text_mob,
        ]),
        ft.Row([
            ft.Container(
                width=110,
                height=1,
                bgcolor='black',
                offset=ft.transform.Offset(-0.05,0)
            )
        ])
    ],spacing=5),
    on_click=True
)

def close_burger_menu(page: ft.Page):
    nav_mobile.height=75
    nav_mobile.opacity=1
    page.update()
    nav_mobile.content=ft.Row([
        ft.Row([
          ft.Image(
            src='logo/logo.png',
            scale=ft.transform.Scale(0.9)
        ),  
        ],alignment=ft.MainAxisAlignment.START),
        ft.Row([
            burger_menu
        ],alignment=ft.MainAxisAlignment.END,expand=True,offset=ft.transform.Offset(-0.1,0),spacing=25)
        
        
    ],expand=True)
    page.update()
    

def open_burger_menu(page: ft.Page):
    nav_mobile.height=325
    nav_mobile.opacity=0.9
    page.update()
    nav_mobile.content=ft.Column([
        ft.Row([
            ft.Row([
                ft.Image(
                    src='logo/logo.png',
                    scale=ft.transform.Scale(1.1)
                ),  
            ],alignment=ft.MainAxisAlignment.START),
            ft.Row([
                burger_menu
            ],alignment=ft.MainAxisAlignment.END,expand=True,offset=ft.transform.Offset(-0.1,0),spacing=25)
        
        
        ],expand=True),
        ft.Row([
            home_click,
        ]),
        ft.Row([
            about_click,
        ]),
        ft.Row([
            blog_click,
        ]),
        ft.Row([
            pricing_click,
        ]),
        ft.Row([
            contact_btn_mob,
        ]),
        ft.Row([
            ft.Container(
                width=1,
                height=25
            )
        ])
    ],spacing=25)
    page.update()


burger_menu = ft.Container(
    content=ft.Row([
        ft.Icon(
            name=ft.icons.MENU,
            color='black'
        )
    ])
)

nav_mobile = ft.Container(
    expand=True,
    height=75,
    bgcolor='white',
    padding=ft.padding.only(25,15),
    content=ft.Row([
        ft.Row([
          ft.Image(
            src='logo/logo.png',
            scale=ft.transform.Scale(0.9)
        ),  
        ],alignment=ft.MainAxisAlignment.START),
        ft.Row([
            burger_menu
        ],alignment=ft.MainAxisAlignment.END,expand=True,offset=ft.transform.Offset(-0.1,0),spacing=25)
        
        
    ],expand=True)
)