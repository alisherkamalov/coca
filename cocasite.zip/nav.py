import flet as ft 

h_btn_text = ft.Text(
        'Home',
        color='black',
        size=15,
        weight=ft.FontWeight.W_400,
    selectable=True,
    )
home_btn = ft.Container(
    content=h_btn_text,
    on_click=True
)
a_btn_text = ft.Text(
        'About',
        color='black',
        size=15,
        weight=ft.FontWeight.W_400,
    selectable=True,
    )
about_btn = ft.Container(
    content=a_btn_text,
    on_click=True
)
b_btn_text = ft.Text(
        'Blog',
        color='black',
        size=15,
        weight=ft.FontWeight.W_400,
    selectable=True,
    )
blog_btn = ft.Container(
    content=b_btn_text,
    on_click=True
)
p_btn_text = ft.Text(
        'Pricing',
        color='black',
        size=15,
        weight=ft.FontWeight.W_400,
    selectable=True,
    )
pricing_btn = ft.Container(
    content=p_btn_text,
    on_click=True
)
c_btn_text = ft.Text(
        'Contact Us ->',
        color='black',
        size=15,
        weight=ft.FontWeight.W_500,
    selectable=True,
        )
contact_btn = ft.Container(
    content=ft.Column([
        ft.Row([
        c_btn_text,
        ]),
        ft.Row([
            ft.Container(
                width=110,
                height=1,
                bgcolor='black',
                offset=ft.transform.Offset(-0.05,0)
            )
        ])
    ],spacing=5),
    on_click=True
)

class Navigation (ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=75
        self.padding=ft.padding.only(75,15)
        self.content=ft.Row([
        ft.Row([
          ft.Image(
            src='logo/logo.png',
            scale=ft.transform.Scale(0.9)
        ),  
        ],alignment=ft.MainAxisAlignment.START),
        ft.Row([
            home_btn,
            about_btn,
            blog_btn,
            pricing_btn,
            ft.Row([
                contact_btn
            ],offset=ft.transform.Offset(0.5,0.3))
            
        ],alignment=ft.MainAxisAlignment.END,expand=True,offset=ft.transform.Offset(-0.175,0),spacing=25)
        
        
    ],expand=True)