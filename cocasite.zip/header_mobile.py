import flet as ft 

text_header1 = ft.Text(
    'Digitally forward creative',
    weight=ft.FontWeight.W_600,
    size=30,
    width=300,
    expand_loose=True,
    selectable=True,
)

text_header2 = ft.Text(
    "Our biggest challenge is making sure we're always designing and building products that will help you run your business better.",
    weight=ft.FontWeight.W_600,
    size=15,
    width=300,
    offset=ft.transform.Offset(0,-0.5),
    expand_loose=True,
    selectable=True,
)

entry_email = ft.CupertinoTextField(
    expand=True,
    border=ft.border.all(0,color='white'),
    color='black',
    bgcolor='#FFFFFF',
    placeholder_text='Enter your email',
    placeholder_style=ft.TextStyle(
        color='grey'
    )
)
text_btn_t_f_f = ft.Text(
            'Try for free',
            color='white',
            weight=ft.FontWeight.W_500,
            size=15,
    selectable=True,
        )

try_for_free_btn = ft.Container(
    width=125,
    height=50,
    border_radius=50,
    bgcolor='black',
    content=ft.Row([
        text_btn_t_f_f
    ],alignment=ft.MainAxisAlignment.CENTER),
    on_click=True
)

text_sales_rep1 = ft.Text(
    'Sales Report',
    weight=ft.FontWeight.W_500,
    size=10,
    color='black',
    selectable=True,
)

text_sales_rep2 = ft.Text(
    'My product',
    weight=ft.FontWeight.W_400,
    size=7.5,
    color='black',
    selectable=True,
)

text_sales_rep3 = ft.Text(
    'Competitor',
    weight=ft.FontWeight.W_400,
    size=7.5,
    color='black',
    selectable=True,
)

data_1 = [
        ft.LineChartData(
            data_points=[
                ft.LineChartDataPoint(2,3.5),
                ft.LineChartDataPoint(3,3.9),
                ft.LineChartDataPoint(4,4),
                ft.LineChartDataPoint(5,4.2),
                ft.LineChartDataPoint(6,4),
                ft.LineChartDataPoint(7,4.1),
                ft.LineChartDataPoint(8,4),
                
            
                
                
            ],
            stroke_width=5,
            color=ft.colors.BLUE,
            curved=True,
            stroke_cap_round=True,
        ),
        ft.LineChartData(
            data_points=[
                ft.LineChartDataPoint(2,3.7),
                ft.LineChartDataPoint(3,3.9),
                ft.LineChartDataPoint(4,3.8),
                ft.LineChartDataPoint(5,4),
                ft.LineChartDataPoint(6,3.9),
                ft.LineChartDataPoint(7,4),
                ft.LineChartDataPoint(8,3.9),
                
            ],
            color=ft.colors.RED,
            below_line_bgcolor=ft.colors.with_opacity(0, ft.colors.RED),
            stroke_width=5,
            curved=True,
            stroke_cap_round=True,
        ),
        
    ]

sales_rep_cont = ft.Container(
    expand=True,
    height=325,
    padding=12.5,
    border_radius=10,
    bgcolor='white',
    shadow=ft.BoxShadow(
        0.0001,
        100,
        color='#E2F8F0'
    ),
    content=ft.Column([
        ft.Row([
            text_sales_rep1
        ]),
        ft.Row([
            ft.Row([
            ft.Container(
                width=12.2,
                height=10,
                bgcolor='blue',
                border_radius=1
            ),
            text_sales_rep2,
            ]),
            ft.Row([
                ft.Container(
                width=12.2,
                height=10,
                bgcolor='red',
                border_radius=1
            ),
            text_sales_rep3,
            ])
            
        ],spacing=50),
        ft.Row([
            ft.Stack([
                ft.LineChart(
                data_series=data_1,
                left_axis=ft.ChartAxis(
                    labels=[
                        ft.ChartAxisLabel(
                            value=1,
                            label=ft.Text("", size=14, weight=ft.FontWeight.BOLD),
                        ),
                        ft.ChartAxisLabel(
                            value=2,
                            label=ft.Text("", size=14, weight=ft.FontWeight.BOLD),
                        ),
                        ft.ChartAxisLabel(
                            value=3,
                            label=ft.Text("", size=14, weight=ft.FontWeight.BOLD),
                        ),
                        ft.ChartAxisLabel(
                            value=4,
                            label=ft.Text("", size=14, weight=ft.FontWeight.BOLD),
                        ),
                        ft.ChartAxisLabel(
                            value=5,
                            label=ft.Text("", size=14, weight=ft.FontWeight.BOLD),
                        ),
                        ft.ChartAxisLabel(
                            value=6,
                            label=ft.Text("", size=14, weight=ft.FontWeight.BOLD),
                        ),
                    ],
                    labels_size=40,
                    show_labels=True
                ),
                expand=True,
                height=346,
                
            ),  
                ft.Column([
                    ft.Text(
                    '1k',
                    color='grey',
                    size=20,
                    offset=ft.transform.Offset(0.5,0)
                    ),
                    ft.Text(
                    '800',
                    color='grey',
                    size=20
                    ),
                    ft.Text(
                    '600',
                    color='grey',
                    size=20
                    ),
                    ft.Text(
                    '400',
                    color='grey',
                    size=20
                    ),
                    ft.Text(
                    '200',
                    color='grey',
                    size=20
                    ),
                    ft.Text(
                    '0',
                    color='grey',
                    size=20,
                    offset=ft.transform.Offset(1.5,0)
                    ),
                    ft.Row([
                    ft.Container(
                        expand=True,
                        bgcolor='white',
                        height=50,
                        
                        shadow=ft.BoxShadow(
                            color='white',
                            spread_radius=5,
                            blur_radius=300
                        ),
                        content=ft.Row([
                            ft.Text(
                                '   ',
                                color='grey',
                                size=10
                            ),
                            ft.Text(
                                'May',
                                color='grey',
                                size=10,
    selectable=True,
                            ),
                            ft.Text(
                                'Jun',
                                color='grey',
                                size=10,
    selectable=True,
                            ),
                            ft.Text(
                                'Jul',
                                color='grey',
                                size=10,
    selectable=True,
                            ),
                            ft.Text(
                                'Aug',
                                color='grey',
                                size=10,
    selectable=True,
                            ),
                            ft.Text(
                                'Sep',
                                color='grey',
                                size=10,
    selectable=True,
                            ),
                            ft.Text(
                                'Oct',
                                color='grey',
                                size=10,
    selectable=True,
                            ),
                        ],spacing=25,alignment=ft.MainAxisAlignment.CENTER,expand=True)
                    )
                ],offset=ft.transform.Offset(0,-0.2))
                
                ]),
                
                
            ],expand=True,)
            
            ])
        ])
    )

text_c_g_c = ft.Text(
            'Customer Growth',
            size=8.75,
            weight=ft.FontWeight.W_600,
            color='black',
    selectable=True,
        )

custom_growth_cont = ft.Container(
    width=118,
    height=150,
    border_radius=10,
    padding=7.5,
    bgcolor='white',
    shadow=ft.BoxShadow(
        0.0001,
        50,
        color='#E2F8F0'
    ),
    content=ft.Column([
        ft.Row([
            text_c_g_c
        ]),
        ft.Row([
            ft.Column([
                ft.Text(
                    '10k',
                    color='grey'
                ),
                ft.Text(
                    '5k',
                    color='grey',
                    offset=ft.transform.Offset(0.3,-0.5)
                ),
                ft.Text(
                    '0',
                    color='grey',
                    offset=ft.transform.Offset(1.3,-1)
                )
            ],spacing=35),
            ft.Column([
                ft.Container(
                    width=10,
                    height=15,
                    bgcolor='#EB6E46',
                    border_radius=25,
                ),
                ft.Container(
                    width=10,
                    height=20,
                    bgcolor='#20BFF7',
                    border_radius=25,
                ),
                ft.Container(
                    width=10,
                    height=25,
                    bgcolor='blue',
                    border_radius=25,
                ),
                ft.Text(
                    'Jan',
                    color='grey',
    selectable=True,
                )
                
            ],spacing=5,alignment=ft.MainAxisAlignment.END),
            ft.Column([
                ft.Container(
                    width=10,
                    height=10,
                    bgcolor='#EB6E46',
                    border_radius=25,
                ),
                ft.Container(
                    width=10,
                    height=15,
                    bgcolor='#20BFF7',
                    border_radius=25,
                ),
                ft.Container(
                    width=10,
                    height=10,
                    bgcolor='blue',
                    border_radius=25,
                ),
                ft.Text(
                    'Feb',
                    color='grey',
    selectable=True,
                )
                
            ],spacing=5,offset=ft.transform.Offset(0,0.175)),
        ])
        
    ])
)

black_cont = ft.Container(
    expand=True,
    height=119,
    border_radius=10,
    padding=15,
    bgcolor='black',
    content=ft.Row([
        ft.Column([
            ft.Text(
                'Sales',
                color='grey',
                    scale=ft.transform.Scale(0.990),
    selectable=True,
            ),
            ft.Text(
                '$31,092',
                color='white',
                size=20,
                weight=ft.FontWeight.W_500,
                    scale=ft.transform.Scale(0.990),
    selectable=True,
            ),
            ft.Row([
                ft.Text(
                '+4.2%',
                color='green',
                    scale=ft.transform.Scale(0.990),
    selectable=True,
                
                ),
                ft.Text(
                    'from latest year',
                    color='grey',
                    scale=ft.transform.Scale(0.9),
    selectable=True,
                )
            ])
            
        ]),
        ft.Column([
            ft.Text(
                'Marketing',
                color='grey',
                    scale=ft.transform.Scale(0.990),
    selectable=True,
            ),
            ft.Text(
                '$29,128',
                color='white',
                size=20,
                weight=ft.FontWeight.W_500,
                    scale=ft.transform.Scale(0.990),
    selectable=True,
            ),
            ft.Row([
                ft.Text(
                '-4.2%',
                color='red',
                scale=ft.transform.Scale(0.990),
    selectable=True,
                
                ),
                ft.Text(
                    'from latest year',
                    color='grey',
                    scale=ft.transform.Scale(0.9),
    selectable=True,
                )
            ])
            
        ]),
    ],alignment=ft.MainAxisAlignment.SPACE_EVENLY)
)
class HeaderMobile (ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=1250
        self.padding=ft.padding.only(25,25)
        self.content=ft.Column([
        ft.Column([
            ft.Row([
                ft.Stack([
                    ft.Container(
                        width=5,
                        height=5,
                        border_radius=50,
                        shadow=ft.BoxShadow(
                            spread_radius=5,
                            blur_radius=300,
                            color='#FA7515',
                            
                        ),
                        scale=ft.transform.Scale(11),
                        offset=ft.transform.Offset(25,15)
                    ),
                    text_header1
                ])
                
            ]),
            ft.Row([
                ft.Container(
                    width=10,
                    height=1,
                    bgcolor='black',
                    offset=ft.transform.Offset(0,-72.5)
                ),
                text_header2
            ]),
            ft.Row([
                entry_email,
                try_for_free_btn,
                ft.Container(
                    width=25,
                    height=5,
                )
            ]),
            ft.Row([
                ft.Container(
                    width=200,
                    height=1,
                    bgcolor='grey'
                )
            ],offset=ft.transform.Offset(0,-100))
            
        ],spacing=100),
    ft.Column([
        ft.Stack([
            ft.Container(
                width=5,
                        height=5,
                        border_radius=50,
                        shadow=ft.BoxShadow(
                            spread_radius=30,
                            blur_radius=100,
                            color='#E2F8F0',
                            
                        ),
                        scale=ft.transform.Scale(11),
                        offset=ft.transform.Offset(75,90)
            ),
            ft.Row([
                sales_rep_cont,
                ft.Container(
                        width=25,
                        height=5,
                    ),
            ],offset=ft.transform.Offset(0,0.2)),
            ft.Row([
                custom_growth_cont
            ],offset=ft.transform.Offset(0,0),expand=True,alignment=ft.MainAxisAlignment.END),
            ft.Row(
                [
                    black_cont,
                    ft.Container(
                        width=25,
                        height=5,
                    )
                ],offset=ft.transform.Offset(0,4)
            )
            
        ])
    ])
    ],offset=ft.transform.Offset(0,0))