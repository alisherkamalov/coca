import flet as ft 


overview_text1_mob = ft.Text(
    'Sans help our client solve complex customer problems with date that does more.',
    size=25,
    width=400,
    expand_loose=True,
    color='white',
    weight=ft.FontWeight.W_500,
    selectable=True,
    
)
overview_text2_mob = ft.Text(
    'Our platform offers the modern enterprise full control of how date can be access and used with industry leading software solutions for identity, activation, and date collaboration',
    size=15,
    width=325,
    expand_loose=True,
    color='grey',
    selectable=True,
    
)

overview_text3_mob = ft.Text(
    'Build your date fundamental',
    size=20,
    width=300,
    expand_loose=True,
    color='white',
    weight=ft.FontWeight.W_500,
    selectable=True,
    
)

overview_text4_mob = ft.Text(
    'Build access to date, develop valuable business insights and drive revenue while maintaining full control over access and use of date at all times.',
    size=15,
    width=375,
    expand_loose=True,
    color='grey',
    selectable=True,
    
)

overview_text7_mob = ft.Text(
    'Activate your date',
    size=20,
    width=500,
    expand_loose=True,
    color='white',
    weight=ft.FontWeight.W_500,
    selectable=True,
    
)

overview_text8_mob = ft.Text(
    'Accurately address your specific audiences at scale across any channel, platform, publisher or network and safely translate date between identity space to improve results.',
    size=15,
    width=325,
    expand_loose=True,
    color='grey',
    selectable=True,
    
)

overview_text5_mob = ft.Text(
    'Measure more effective',
    size=20,
    width=500,
    expand_loose=True,
    color='white',
    weight=ft.FontWeight.W_500,
    selectable=True,
    
)

overview_text6_mob = ft.Text(
    'Effectively measure people-based campaigns with the freedom to choose from best-of breed partners to optimize and drive media innovation.',
    size=15,
    width=360,
    expand_loose=True,
    color='grey',
    selectable=True,
    
)

overview_text9_mob = ft.Text(
    'Strengthen consumer privacy',
    size=20,
    width=550,
    expand_loose=True,
    color='white',
    weight=ft.FontWeight.W_500,
    selectable=True,
    
)

overview_text10_mob = ft.Text(
    'Protect your customer date with leading privacy-preserving technologies and advanced techniques to minimize date movement while still enabling insight generation.',
    size=15,
    width=350,
    expand_loose=True,
    color='grey',
    selectable=True,
    
)

class OverviewMobile (ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=1150
        self.bgcolor='#1D1E25'
        self.padding=15
        self.content=ft.Column([
        ft.Row([
            overview_text1_mob
        ]),
        ft.Row([
            overview_text2_mob
        ]),
        ft.Column([
            ft.Column([
                ft.Row([
                    ft.Container(
                    width=5,
                    height=25
                ),
                ]),
                ft.Row([
                    ft.Image(
                        src='icons/icon1.png',width=30,height=30
                    )
                ]),
                ft.Row([
                    overview_text3_mob
                ]),
                ft.Row([
                    overview_text4_mob
                ]),
                ft.Row([
                    ft.Container(
                        width=5,
                        height=25
                    ),
                ]),
                ft.Row([
                        ft.Image(
                            src='icons/icon2.png',width=30,height=30
                        )
                ]),
                ft.Row([
                        overview_text5_mob
                ]),
                ft.Row([
                        overview_text6_mob
                    ]),
                ]),
            ft.Column([
                ft.Row([
                    ft.Container(
                        width=5,
                        height=25
                    ),
                ]),
                ft.Row([
                    ft.Image(
                        src='icons/icon3.png',
                        width=30,
                        height=30
                    )
                ]),
                ft.Row([
                    overview_text7_mob
                ]),
                ft.Row([
                    overview_text8_mob
                ]),
                ft.Row([
                    ft.Container(
                    width=5,
                    height=25
                ),
                ]),
                ft.Row([
                    ft.Image(
                        src='icons/icon4.png',
                        width=30,
                        height=30
                    )
                ]),
                ft.Row([
                    overview_text9_mob
                ]),
                ft.Row([
                    overview_text10_mob
                ]),
            ])
                
        
        ],spacing=25)
    ],alignment=ft.MainAxisAlignment.START)
    


