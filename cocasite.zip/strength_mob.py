import flet as ft


class StrengthMobile(ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=700
        self.padding=ft.padding.only(0,0)
        self.content=ft.Column([
        ft.Container(
            expand=True,
            height=250,
            content=ft.Row([
                ft.Row([
                    
                    ft.Column([
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '17k',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'happy customers on worldwide',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=200,
    selectable=True,
                            )
                        ]),
                
                    ]),
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '15+',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'Hours of work experience',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=150,
    selectable=True,
                            )
                        ]),
                    ]),
                ]),
                ft.Column([
                    ft.Row([
                        ft.Container(
                            width=1,
                            height=79,
                            bgcolor='grey',
                            offset=ft.transform.Offset(-12.5,0.4)
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            width=1,
                            height=79,
                            bgcolor='grey',
                            offset=ft.transform.Offset(-12.5,0.6)
                        )
                    ]),
                        
                    ],spacing=25),
                ft.Column([
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '50+',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'Creativity & passionate members',
                                size=12.5,
                                color='grey',
                                expand_loose=True,
                                width=200,
    selectable=True,
                            )
                        ]),
                    ]),
                    ft.Column([
                        ft.Row([
                            ft.Text(
                                '100+',
                                size=45,
                                weight=ft.FontWeight.W_600,
                                color='black',
    selectable=True,
                            )
                        ]),
                        ft.Row([
                            ft.Text(
                                'Integrations lorem ipsum integrations',
                                size=15,
                                color='grey',
                                expand_loose=True,
                                width=150,
    selectable=True,
                            )
                        ]),
                    ]),
                ]),
                ],alignment=ft.MainAxisAlignment.CENTER,expand=True,spacing=25)
            
            
        ],alignment=ft.MainAxisAlignment.CENTER,expand=True,height=250,scale=ft.transform.Scale(0.8),offset=ft.transform.Offset(0.05,0)),
        ),
        
        ft.Row([
            ft.Container(
                width=25,
                height=1
            ),
            ft.Image(
                src='images/image2.png',
                expand=True
            )
        ],alignment=ft.MainAxisAlignment.CENTER,expand=True,offset=ft.transform.Offset(0,-0.1),scale=ft.transform.Scale(1)),
        ft.Row([
            ft.Container(
                expand=True,
                height=221,
                
                padding=ft.padding.only(35,0),
                content=ft.Column([
                    ft.Row([
                        ft.Text(
                        'Drive sustainable growth with personal and engaging experiences',
                        size=25,
                        weight=ft.FontWeight.W_600,
                        color='black',
                        width=350,
                        expand_loose=True,
    selectable=True,
                    )
                    ],alignment=ft.MainAxisAlignment.CENTER,expand=True,scroll=False),
                    ft.Row([
                        ft.Text(
                        'To build software that gives customer facing teams in small and medium-sized businesses the ability to create rewarding and long-lasting relationships with customers',
                        size=15.5,
                        color='grey',
                        width=350,
                        expand_loose=True,
    selectable=True,
                    )
                    ],alignment=ft.MainAxisAlignment.CENTER,expand=True)
                    
                ],scroll=False)
            ),
        ],offset=ft.transform.Offset(0,-0.15),alignment=ft.MainAxisAlignment.CENTER,expand=True)
        
        
    ],offset=ft.transform.Offset(-0.05,0),spacing=25)
