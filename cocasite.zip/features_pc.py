import flet as ft 


features_text1 = ft.Text(
    'Passion to increase company revenue up to 85%',
    color='black',
    weight=ft.FontWeight.W_600,
    width=505,
    expand_loose=True,
    size=45,
    selectable=True,
)

features_text2 = ft.Text(
    'Automate your sales, marketing and service in one platform. Avoid date leaks and enable consistent messaging',
    color='grey',
    width=325,
    expand_loose=True,
    size=17.5,
    selectable=True,
)

frame_features_pc1 = ft.Container(
    content=ft.Column([
        ft.Row([
            ft.Image(
                src='icons/icon5.png',
                width=18,
                height=18
            ),
            ft.Text(
                'Close more deals with single - page contact managment',
                color='black',
                weight=ft.FontWeight.W_600,
                width=275,
                expand_loose=True,
                size=15,
    selectable=True,
            )
        ],spacing=15),
        ft.Row([
            ft.Image(
                src='icons/icon5.png',
                width=18,
                height=18
            ),
            ft.Text(
                'Enjoy one-click calling, call scripts and voicemail automation',
                color='black',
                weight=ft.FontWeight.W_600,
                width=275,
                expand_loose=True,
                size=15,
    selectable=True,
            )
        ],spacing=15),
        ft.Row([
            ft.Image(
                src='icons/icon5.png',
                width=18,
                height=18
            ),
            ft.Text(
                'Take stages and milestones of your deals to keep the sales process an track',
                color='black',
                weight=ft.FontWeight.W_600,
                width=285,
                expand_loose=True,
                size=15,
    selectable=True,
            )
        ],spacing=15),
        
    ],spacing=50)
)

bar_chart_btn_pc = ft.Container(
    content=ft.Icon(
        name=ft.icons.MORE_HORIZ,
        color='grey'
    ),
    on_click=True
)

class BarChartPc (ft.Container):
    def __init__(self):
        super().__init__()
        self.width=290
        self.height=358
        self.padding=25
        self.bgcolor='white'
        self.content=ft.Column([
        ft.Row([
            ft.Text(
                'Statictic',
                weight=ft.FontWeight.W_700,
                size=20,
                color='black',
    selectable=True,
            ),
            ft.Container(
                width=115,
                height=1
            ),
            bar_chart_btn_pc
        ]),
        ft.Row([
            ft.Column([
                ft.Container(
                    width=95,
                    height=87,
                    content=ft.Row([
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=40,
                            bgcolor='#1463FF',
                            border_radius=25
                            ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=55,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=47,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=65,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=87,
                            bgcolor='#1463FF',
                            border_radius=25
                        )
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        
                        
                        
                        
                    ],spacing=15)
                )
            ]),
            ft.Column([
                ft.Row(
                    [
                        ft.Text(
                            'Total Income',
                            color='grey',
    selectable=True,
                        )
                    ]
                ),
                ft.Row([
                    ft.Text(
                        '$7.020',
                        color='black',
                        size=20,
                        weight=ft.FontWeight.W_600,
    selectable=True,
                    ),
                    ft.Row([
                        ft.Text(
                        '+',
                        color='green',
                        size=20,
                        offset=ft.transform.Offset(0,-0.05),
    selectable=True,
                        
                        ),
                        ft.Text(
                            '15%',
                            color='black',
                            weight=ft.FontWeight.W_500,
    selectable=True,
                        )
                    ],spacing=1)
                    
                ],spacing=10),
                ft.Row([
                    ft.Text(
                        'Your ',
                        color='grey',
                        width=150,
                        expand_loose=True,
                        size=10,
    selectable=True,
                        spans=[
                            ft.TextSpan(
                                'Income ',
                                ft.TextStyle(
                                    color='grey',
                                    weight=ft.FontWeight.W_500,
                                ),
                                
                            ),
                            ft.TextSpan(
                                'of this month compared to last month',
                                ft.TextStyle(
                                color='grey',
                                ),
                                
                            )
                        ]
                    )
                ])
            ],height=87,alignment=ft.MainAxisAlignment.START,offset=ft.transform.Offset(0,-0.05))
        ],spacing=25),
        ft.Row([
            ft.Container(
                width=235,
                height=1,
                bgcolor='grey'
            )
        ]),
        ft.Row([
            ft.Column([
                ft.Container(
                    width=95,
                    height=87,
                    content=ft.Row([
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=55,
                            bgcolor='#1463FF',
                            border_radius=25
                            ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=65,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=49,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=40,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=32,
                            bgcolor='#1463FF',
                            border_radius=25
                        )
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        
                        
                        
                        
                    ],spacing=15)
                )
            ]),
            ft.Column([
                ft.Row(
                    [
                        ft.Text(
                            'Total Expense',
                            color='grey',
    selectable=True,
                        )
                    ]
                ),
                ft.Row([
                    ft.Text(
                        '$2.150',
                        color='black',
                        size=20,
                        weight=ft.FontWeight.W_600,
    selectable=True,
                    ),
                    ft.Row([
                        ft.Text(
                        '-',
                        color='red',
                        size=20,
                        offset=ft.transform.Offset(0,-0.05),
    selectable=True,
                        
                        ),
                        ft.Text(
                            '10%',
                            color='black',
                            weight=ft.FontWeight.W_500,
    selectable=True,
                        )
                    ],spacing=1)
                    
                ],spacing=10),
                ft.Row([
                    ft.Text(
                        'Your ',
                        color='grey',
                        width=150,
                        expand_loose=True,
                        size=10,
    selectable=True,
                        
                        spans=[
                            ft.TextSpan(
                                'Expense ',
                                ft.TextStyle(
                                    color='grey',
                                    weight=ft.FontWeight.W_500,
                                ),
                                
                            ),
                            ft.TextSpan(
                                'of this month compared to last month',
                                ft.TextStyle(
                                color='grey'
                                ),
                            )
                        ]
                    )
                ])
            ],height=87,alignment=ft.MainAxisAlignment.START,offset=ft.transform.Offset(0,-0.05))
        ],spacing=25),
    ],spacing=25)

class FeaturesPc (ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=1000
        self.padding=ft.padding.only(0,100)
        self.content=ft.Row([
        ft.Column([
            ft.Stack([
                ft.Image(
                src='images/image1.png',
                width=585,
                height=751
                ),
                ft.Row([
                    BarChartPc()
                ],width=580,height=751,alignment=ft.MainAxisAlignment.END,offset=ft.transform.Offset(-0.05,0.15))
            ])
            
        ]),
        ft.Column([
            ft.Row([
                features_text1
            ]),
            ft.Row([
                features_text2
            ]),
            ft.Row([
                ft.Container(
                    width=1,
                    height=25
                )
            ]),
            ft.Row([
                frame_features_pc1
            ])
        ],spacing=25)
    ],alignment=ft.MainAxisAlignment.CENTER,spacing=50)
