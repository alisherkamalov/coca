import flet as ft
from nav import Navigation
from header_pc import HeaderPc,orange_shadow
from header_mobile import HeaderMobile
from header_laptop import HeaderLaptop
from nav_mobile import nav_mobile,burger_menu,open_burger_menu,close_burger_menu
from overview_pc import OverviewPc
from overview_laptop import OverviewLaptop
from overview_mobile import OverviewMobile
from features_pc import FeaturesPc
from features_lap import FeaturesLaptop
from features_mob import FeaturesMobile
from strength_pc import StrengthPc
from partners_pc import PartnersPc
from partners_lap import PartnersLaptop
from partners_mob import PartnersMobile
from strength_lap import StrengthLaptop
from strength_mob import StrengthMobile



class Main():
    def main(page: ft.Page):
        page.fonts = {
            'Inter':'fonts/inter.ttf'
        }
        page.theme = ft.Theme(font_family="Inter")
        page.route='/home'
        page.theme_mode = 'light'
        widthtext = ft.Text(
            f'{page.width} px',
            size=50
        )
        page.padding = 0
        page.spacing = 0
        page.bgcolor='#FFFFFF'
        page.scroll='always'

        
        def init_close_burger_menu(event):
            close_burger_menu(page)
            burger_menu.on_click=init_open_burger_menu
            page.update()
        
        def init_open_burger_menu(event):
            open_burger_menu(page)
            burger_menu.on_click=init_close_burger_menu
            page.update()
            
        
        
        page.window_width = 400
        def adaptive(event):
            widthtext.value = f'{page.width} px'
            page.clean()
            if 3001 < page.width < 6000:
                page.clean()
                orange_shadow.scale=ft.transform.Scale(40)
                page.add(
                            ft.Column([
                            ft.Row([
                                Navigation()
                            ]),
                            ft.Row([
                                HeaderPc()
                            ],alignment=ft.MainAxisAlignment.CENTER,),
                        ],alignment=ft.MainAxisAlignment.CENTER,),
                            ft.Row([
                                OverviewPc()
                            ]),
                            ft.Row([
                                FeaturesPc()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([
                                StrengthPc()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([
                                PartnersPc()
                            ],alignment=ft.MainAxisAlignment.CENTER)
                )
            if 1248 < page.width < 3000:
                page.clean()
                orange_shadow.scale=ft.transform.Scale(15)
                page.add(
                            ft.Column([
                            ft.Row([
                                Navigation()
                            ]),
                            ft.Row([
                                HeaderPc()
                            ],alignment=ft.MainAxisAlignment.CENTER,),
                        ],alignment=ft.MainAxisAlignment.CENTER,),
                            ft.Row([
                                OverviewPc()
                            ]),
                            ft.Row([
                                FeaturesPc()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([
                                StrengthPc()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([
                                PartnersPc()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                )
            if 300 < page.width < 853:
                page.clean()
                page.add(
                            ft.Column([
                                    ft.Row([
                                        nav_mobile
                                    ]),
                                    ft.Row([
                                        HeaderMobile()
                                    ]),
                                    ft.Row([
                                        OverviewMobile()
                                    ]),
                                    ft.Row([
                                        FeaturesMobile()
                                    ]),
                                    ft.Row([
                                        StrengthMobile()
                                    ]),
                                    ft.Row([
                                        PartnersMobile()
                                    ]),
                        ],spacing=0)

                )
            if 854 < page.width < 1248:
                page.clean()
                page.add(
                            ft.Column([
                            ft.Row([
                                Navigation()
                            ]),
                            ft.Row([
                                HeaderLaptop()
                            ]),
                            ft.Row([
                                OverviewLaptop()
                            ]),
                            ft.Row([
                                FeaturesLaptop()
                            ]),
                            ft.Row([
                                StrengthLaptop()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([
                                PartnersLaptop()
                            ],alignment=ft.MainAxisAlignment.CENTER),
                            
                            
                        ])
                )
            page.update()
        page.on_resized = adaptive
        adaptive(None)
        #page.overlay.append(widthtext)
        burger_menu.on_click=init_open_burger_menu
        page.update()
    

ft.app(
        Main.main,
        assets_dir='assets', 
        web_renderer=ft.WebRenderer.CANVAS_KIT,
        view=ft.WEB_BROWSER
    )