import flet as ft 


features_text1_mob = ft.Text(
    'Passion to increase company revenue up to 85%',
    color='black',
    weight=ft.FontWeight.W_600,
    width=495,
    expand_loose=True,
    size=35,
    selectable=True,
)

features_text2_mob = ft.Text(
    'Automate your sales, marketing and service in one platform. Avoid date leaks and enable consistent messaging',
    color='grey',
    width=425,
    expand_loose=True,
    size=17.5,
    selectable=True,
)

frame_features_mob1 = ft.Container(
    content=ft.Column([
        ft.Row([
            ft.Image(
                src='icons/icon5.png',
                width=18,
                height=18
            ),
            ft.Text(
                'Close more deals with single - page contact managment',
                color='black',
                weight=ft.FontWeight.W_600,
                width=350,
                expand_loose=True,
                size=15,
    selectable=True,
            )
        ],spacing=15),
        ft.Row([
            ft.Image(
                src='icons/icon5.png',
                width=18,
                height=18
            ),
            ft.Text(
                'Enjoy one-click calling, call scripts and voicemail automation',
                color='black',
                weight=ft.FontWeight.W_600,
                width=300,
                expand_loose=True,
                size=15,
    selectable=True,
            )
        ],spacing=15),
        ft.Row([
            ft.Image(
                src='icons/icon5.png',
                width=18,
                height=18
            ),
            ft.Text(
                'Take stages and milestones of your deals to keep the sales process an track',
                color='black',
                weight=ft.FontWeight.W_600,
                width=350,
                expand_loose=True,
                size=15,
    selectable=True,
            )
        ],spacing=15),
        
    ],spacing=50)
)

bar_chart_btn_mob = ft.Container(
    content=ft.Icon(
        name=ft.icons.MORE_HORIZ,
        color='grey'
    ),
    on_click=True
)

class BarChartMobile (ft.Container):
    def __init__(self):
        super().__init__()
        self.width=290
        self.height=358
        self.padding=25
        self.scale=ft.transform.Scale(0.6)
        self.offset=ft.transform.Offset(0.275,0.2)
        self.bgcolor='white'
        self.content=ft.Column([
        ft.Row([
            ft.Text(
                'Statictic',
                weight=ft.FontWeight.W_700,
                size=20,
                color='black',
    selectable=True,
            ),
            ft.Container(
                width=115,
                height=1
            ),
            bar_chart_btn_mob
        ]),
        ft.Row([
            ft.Column([
                ft.Container(
                    width=95,
                    height=87,
                    content=ft.Row([
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=40,
                            bgcolor='#1463FF',
                            border_radius=25
                            ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=55,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=47,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=65,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=87,
                            bgcolor='#1463FF',
                            border_radius=25
                        )
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        
                        
                        
                        
                    ],spacing=15)
                )
            ]),
            ft.Column([
                ft.Row(
                    [
                        ft.Text(
                            'Total Income',
                            color='grey',
    selectable=True,
                        )
                    ]
                ),
                ft.Row([
                    ft.Text(
                        '$7.020',
                        color='black',
                        size=20,
                        weight=ft.FontWeight.W_600,
    selectable=True,
                    ),
                    ft.Row([
                        ft.Text(
                        '+',
                        color='green',
                        size=20,
                        offset=ft.transform.Offset(0,-0.05),
    selectable=True,
                        
                        ),
                        ft.Text(
                            '15%',
                            color='black',
                            weight=ft.FontWeight.W_500,
    selectable=True,
                        )
                    ],spacing=1)
                    
                ],spacing=10),
                ft.Row([
                    ft.Text(
                        'Your ',
                        color='grey',
                        width=150,
                        expand_loose=True,
                        size=10,
    selectable=True,
                        spans=[
                            ft.TextSpan(
                                'Income ',
                                ft.TextStyle(
                                    color='grey',
                                    weight=ft.FontWeight.W_500
                                ),
                                
                            ),
                            ft.TextSpan(
                                'of this month compared to last month',
                                ft.TextStyle(
                                color='grey'
                                ),
                            )
                        ]
                    )
                ])
            ],height=87,alignment=ft.MainAxisAlignment.START,offset=ft.transform.Offset(0,-0.05))
        ],spacing=25),
        ft.Row([
            ft.Container(
                width=235,
                height=1,
                bgcolor='grey'
            )
        ]),
        ft.Row([
            ft.Column([
                ft.Container(
                    width=95,
                    height=87,
                    content=ft.Row([
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=55,
                            bgcolor='#1463FF',
                            border_radius=25
                            ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=65,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=49,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=40,
                            bgcolor='#1463FF',
                            border_radius=25
                        ),
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        ft.Column([
                            ft.Container(
                            width=8,
                            height=32,
                            bgcolor='#1463FF',
                            border_radius=25
                        )
                        ],alignment=ft.MainAxisAlignment.END,height=87),
                        
                        
                        
                        
                    ],spacing=15)
                )
            ]),
            ft.Column([
                ft.Row(
                    [
                        ft.Text(
                            'Total Expense',
                            color='grey',
    selectable=True,
                        )
                    ]
                ),
                ft.Row([
                    ft.Text(
                        '$2.150',
                        color='black',
                        size=20,
                        weight=ft.FontWeight.W_600,
    selectable=True,
                    ),
                    ft.Row([
                        ft.Text(
                        '-',
                        color='red',
                        size=20,
                        offset=ft.transform.Offset(0,-0.05),
    selectable=True,
                        
                        ),
                        ft.Text(
                            '10%',
                            color='black',
                            weight=ft.FontWeight.W_500,
    selectable=True,
                        )
                    ],spacing=1)
                    
                ],spacing=10),
                ft.Row([
                    ft.Text(
                        'Your ',
                        color='grey',
                        width=150,
                        expand_loose=True,
    selectable=True,
                        size=10,
                        spans=[
                            ft.TextSpan(
                                'Expense ',
                                ft.TextStyle(
                                    color='grey',
                                    weight=ft.FontWeight.W_500,
                                ),
                                
                            ),
                            ft.TextSpan(
                                'of this month compared to last month',
                                ft.TextStyle(
                                color='grey',
                                )
                            )
                        ]
                    )
                ])
            ],height=87,alignment=ft.MainAxisAlignment.START,offset=ft.transform.Offset(0,-0.05))
        ],spacing=25),
    ],spacing=25)
    


class FeaturesMobile (ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=800
        self.padding=ft.padding.only(15,25)
        self.content=ft.Column([
        ft.Column([
            ft.Stack([
                ft.Row([
                    ft.Image(
                src='images/image1.png',
                width=335,
                height=374
                ),
                    
                ]),
                    BarChartMobile()
                
            ])
            
        ]),
        ft.Column([
            ft.Row([
                features_text1_mob
            ],scale=ft.transform.Scale(0.6),offset=ft.transform.Offset(-0.190,-0.350)),
            ft.Row([
                features_text2_mob
            ],scale=ft.transform.Scale(0.8),offset=ft.transform.Offset(-0.090,-0.85)),
            ft.Row([
                ft.Container(
                    width=1,
                    height=25
                )
            ]),
            ft.Row([
                frame_features_mob1
            ],scale=ft.transform.Scale(0.8),offset=ft.transform.Offset(-0.1,-0.60))
        ],spacing=25)
    ],alignment=ft.MainAxisAlignment.CENTER,spacing=50)
