import flet as ft 


class PartnersMobile(ft.Container):
    def __init__(self):
        super().__init__()
        self.expand=True
        self.height=450
        self.padding=ft.padding.only(0,5)
        self.content=ft.Column([
            ft.Row([
                ft.Column([
                    ft.Column([
                        ft.Column([
                            ft.Text(
                                '890+',
                                color='black',
                                weight=ft.FontWeight.W_600,
                                size=25,
    selectable=True,
                            ),
                            ft.Text(
                                'some big companies that we work with, and trust us very much',
                                color='grey',
                                expand_loose=True,
                                width=250,
    selectable=True,
                            ),
                        ],spacing=15),
                    ],spacing=25),
                        ft.Column([
                            ft.Row([
                                ft.Row([
                                    ft.Image(
                                        src='logo/airbnb_logo.png',
                                        scale=ft.transform.Scale(1)
                                    )
                                ]),
                                ft.Row([
                                    ft.Image(
                                        src='logo/google_logo.png',
                                        scale=ft.transform.Scale(1),
                                        offset=ft.transform.Offset(0.05,0)
                                    )
                                ]),
                    
                            ],spacing=100),
                            ft.Row([
                                ft.Row([
                                    ft.Image(
                                        src='logo/amazon_logo.png',
                                        scale=ft.transform.Scale(1)
                                    )
                                ]),
                                ft.Row([
                                    ft.Image(
                                        src='logo/ola_logo.png',
                                        scale=ft.transform.Scale(1)
                                    )
                                ]),
                    
                            ],spacing=100),
                            ft.Row([
                                ft.Row([
                                    ft.Image(
                                        src='logo/fedex_logo.png',
                                        scale=ft.transform.Scale(1)
                                    )
                                ]),
                                ft.Row([
                                    ft.Image(
                                        src='logo/walm_logo.png',
                                        scale=ft.transform.Scale(1)
                                    )
                                ]),
                    
                            ],spacing=100),
                            ft.Row([
                                ft.Row([
                                    ft.Image(
                                        src='logo/mike_logo.png',
                                        scale=ft.transform.Scale(1)
                                    )
                                ]),
                                ft.Row([
                                    ft.Image(
                                        src='logo/oyo_logo.png',
                                        scale=ft.transform.Scale(1),
                                        offset=ft.transform.Offset(-0.2,0)
                                    )
                                ]),
                    
                            ],spacing=100),
                        ],spacing=100,scale=ft.transform.Scale(0.6),offset=ft.transform.Offset(-0.15,-0.1))
                        ])
                
            ],expand=True,alignment=ft.MainAxisAlignment.CENTER)
        
        
    ])